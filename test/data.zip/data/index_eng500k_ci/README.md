This contains a Netspeak 4 index generated from an English case insensitive (lowercase) dataset where only phrases with a frequency >= 500k were used. As such, the index contains only a very limited set of phrases.

## Stats

| n | Number of n-grams |
| --- | --- |
| 1 | 61738 |
| 2 | 154797 |
| 3 | 77687 |
| 4 | 20569 |
| 5 | 7271 |
| | |
| __Total__ | __322062__ |

Number of unique words: 61741.
